# Library Manager — Stable v2

This build adds:
- Robust **search** (safe rebind)
- **Add/Edit/Delete** for Items, Members, Loans (with active-loan guard)
- Live **status bar** (counts + current selection)
- **JSON persistence** on close/open

Run steps:
1) Open `LibraryManager.sln` in Visual Studio 2022+ (Windows).
2) Right-click **Library.App** → *Set as Startup Project*.
3) Build (Ctrl+Shift+B) → Run (F5).