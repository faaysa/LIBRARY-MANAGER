// ============================================================================
// Library.Domain - Librarian.cs
// Staff type derived from Person.
// ============================================================================
namespace Library.Domain
{
    public class Librarian : Person
    {
        public string EmployeeId { get; set; } = string.Empty;
    }
}