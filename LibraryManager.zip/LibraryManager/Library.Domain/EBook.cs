// ============================================================================
// Library.Domain - EBook.cs
// Digital book with FileSizeMb property. Inherits from Item.
// ============================================================================
namespace Library.Domain
{
    public class EBook : Item
    {
        private double _fileSizeMb;
        public double FileSizeMb
        {
            get => _fileSizeMb;
            set => _fileSizeMb = value < 0
                ? throw new System.ArgumentOutOfRangeException(nameof(FileSizeMb), "File size cannot be negative.")
                : value;
        }

        public override string GetDescription() => $"[EBook] {base.GetDescription()} — {FileSizeMb:F1} MB";
    }
}