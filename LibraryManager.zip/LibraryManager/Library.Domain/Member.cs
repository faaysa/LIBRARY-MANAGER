// ============================================================================
// Library.Domain - Member.cs
// Borrower entity. Inherits Person and adds Email with validation.
// ============================================================================
namespace Library.Domain
{
    public class Member : Person
    {
        private string _email = string.Empty;
        public string Email
        {
            get => _email;
            set => _email = string.IsNullOrWhiteSpace(value)
                ? throw new System.ArgumentException("Email is required.")
                : value.Trim();
        }

        public override string ToString() => $"{FullName} <{Email}>";
    }
}