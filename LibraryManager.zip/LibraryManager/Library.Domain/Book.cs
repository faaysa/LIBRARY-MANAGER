// ============================================================================
// Library.Domain - Book.cs
// Physical book. Adds ISBN and PageCount. Inherits from Item.
// ============================================================================
namespace Library.Domain
{
    public class Book : Item
    {
        private string _isbn = string.Empty;
        private int _pageCount;

        public string Isbn
        {
            get => _isbn;
            set => _isbn = string.IsNullOrWhiteSpace(value)
                ? throw new System.ArgumentException("ISBN is required.")
                : value.Trim();
        }

        public int PageCount
        {
            get => _pageCount;
            set => _pageCount = value <= 0
                ? throw new System.ArgumentOutOfRangeException(nameof(PageCount), "Page count must be positive.")
                : value;
        }

        public override string GetDescription() => $"[Book] {base.GetDescription()} — {PageCount} pages | ISBN: {Isbn}";
    }
}