// ============================================================================
// Library.Domain - Loan.cs
// Links a Member and Item with dates. Provides late-day calculation.
// ============================================================================
using System;

namespace Library.Domain
{
    public class Loan
    {
        private Guid _id = Guid.NewGuid();
        private Item _item;
        private Member _member;
        private DateTime _loanedOn;
        private DateTime _dueDate;
        private DateTime? _returnedOn;

        public Loan(Item item, Member member, DateTime loanedOn, DateTime dueDate)
        {
            _item = item ?? throw new ArgumentNullException(nameof(item));
            _member = member ?? throw new ArgumentNullException(nameof(member));
            _loanedOn = loanedOn;
            _dueDate = dueDate <= loanedOn ? throw new ArgumentException("Due date must be after loan date.") : dueDate;
        }

        public Guid Id => _id;
        public Item Item => _item;
        public Member Member => _member;
        public DateTime LoanedOn => _loanedOn;
        public DateTime DueDate => _dueDate;
        public DateTime? ReturnedOn => _returnedOn;

        public bool IsReturned => _returnedOn.HasValue;
        public bool IsLate(DateTime asOf) => !IsReturned && asOf.Date > _dueDate.Date;

        public int DaysLate(DateTime asOf)
        {
            int days = (asOf.Date - _dueDate.Date).Days;
            return Math.Max(0, days);
        }

        public void MarkReturned(DateTime returnedOn)
        {
            if (returnedOn < _loanedOn) throw new ArgumentException("Return cannot be before loan date.");
            _returnedOn = returnedOn;
        }
    }
}