// ============================================================================
// Library.Domain - Item.cs (stable v2, over-commented)
// Abstract base for all borrowable items. Polymorphism attributes enable JSON
// to remember whether an entry is Book or EBook when persisting collections.
// ============================================================================
using System;
using System.Text.Json.Serialization;

namespace Library.Domain
{
    // Let System.Text.Json know about derived types so List<Item> can be serialized.
    [JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
    [JsonDerivedType(typeof(Book), "book")]
    [JsonDerivedType(typeof(EBook), "ebook")]
    public abstract class Item
    {
        // Encapsulation: private backing fields + validated public properties.
        private Guid _id = Guid.NewGuid();
        private string _title = string.Empty;
        private string _author = string.Empty;
        private int _year;

        // Expose a read-only Id; external code cannot change it.
        public Guid Id => _id;

        public string Title
        {
            get => _title;
            set => _title = string.IsNullOrWhiteSpace(value)
                ? throw new ArgumentException("Title is required.")
                : value.Trim();
        }

        public string Author
        {
            get => _author;
            set => _author = string.IsNullOrWhiteSpace(value)
                ? throw new ArgumentException("Author is required.")
                : value.Trim();
        }

        public int Year
        {
            get => _year;
            set
            {
                int current = DateTime.Now.Year + 1; // allow pre-release
                if (value < 1400 || value > current)
                    throw new ArgumentOutOfRangeException(nameof(Year), "Year is out of reasonable range.");
                _year = value;
            }
        }

        // Virtual description so derived classes can append details (polymorphism).
        public virtual string GetDescription() => $"{Title} by {Author} ({Year})";
    }
}