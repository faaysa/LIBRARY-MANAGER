// ============================================================================
// Library.Domain - Person.cs
// Base for Member/Librarian. Demonstrates encapsulation on name fields.
// ============================================================================
namespace Library.Domain
{
    public abstract class Person
    {
        private System.Guid _id = System.Guid.NewGuid();
        private string _firstName = string.Empty;
        private string _lastName = string.Empty;

        public System.Guid Id => _id;

        public string FirstName
        {
            get => _firstName;
            set => _firstName = string.IsNullOrWhiteSpace(value)
                ? throw new System.ArgumentException("First name is required.")
                : value.Trim();
        }

        public string LastName
        {
            get => _lastName;
            set => _lastName = string.IsNullOrWhiteSpace(value)
                ? throw new System.ArgumentException("Last name is required.")
                : value.Trim();
        }

        public string FullName => $"{FirstName} {LastName}";
    }
}