// ============================================================================
// Library.Domain - SeedData.cs
// Provides initial demo data (>= 10 objects across Items/Members).
// ============================================================================
using System.Collections.Generic;

namespace Library.Domain
{
    public static class SeedData
    {
        public static List<Item> Items() => new()
        {
            new Book { Title = "Clean Code", Author = "Robert C. Martin", Year = 2008, PageCount = 464, Isbn = "9780132350884" },
            new Book { Title = "The Pragmatic Programmer", Author = "Andrew Hunt", Year = 1999, PageCount = 352, Isbn = "9780201616224" },
            new Book { Title = "Design Patterns", Author = "Gamma et al.", Year = 1994, PageCount = 395, Isbn = "9780201633610" },
            new Book { Title = "Refactoring", Author = "Martin Fowler", Year = 1999, PageCount = 431, Isbn = "9780201485677" },
            new EBook{ Title = "You Don't Know JS", Author = "Kyle Simpson", Year = 2015, FileSizeMb = 5.4 },
            new EBook{ Title = "C# in Depth", Author = "Jon Skeet", Year = 2019, FileSizeMb = 7.2 },
            new Book { Title = "Domain-Driven Design", Author = "Eric Evans", Year = 2003, PageCount = 560, Isbn = "9780321125217" },
            new Book { Title = "Working Effectively with Legacy Code", Author = "Michael Feathers", Year = 2004, PageCount = 456, Isbn = "9780131177055" },
        };

        public static List<Member> Members() => new()
        {
            new Member { FirstName = "Ada", LastName = "Lovelace", Email = "ada@example.com" },
            new Member { FirstName = "Alan", LastName = "Turing",  Email = "alan@example.com" },
            new Member { FirstName = "Grace", LastName = "Hopper", Email = "grace@example.com" },
        };
    }
}