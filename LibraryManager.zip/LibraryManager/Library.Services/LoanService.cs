// ============================================================================
// Library.Services - LoanService.cs
// Handles checkout/return and late-fee calculation.
// ============================================================================
using System;
using System.Collections.Generic;
using Library.Domain;

namespace Library.Services
{
    public class LoanService
    {
        private readonly IRepository<Loan> _loans;

        public LoanService(IRepository<Loan> loans) => _loans = loans;

        public Loan Checkout(Item item, Member member, int days = 14)
        {
            if (item is null) throw new ArgumentNullException(nameof(item));
            if (member is null) throw new ArgumentNullException(nameof(member));
            var now = DateTime.Now;
            var loan = new Loan(item, member, now, now.AddDays(days));
            _loans.Add(loan);
            return loan;
        }

        public void Return(Loan loan)
        {
            if (loan is null) throw new ArgumentNullException(nameof(loan));
            loan.MarkReturned(DateTime.Now);
        }

        public decimal LateFee(Loan loan, decimal dailyRate)
        {
            int days = loan.DaysLate(DateTime.Now);
            return dailyRate * days;
        }

        public IEnumerable<Loan> AllLoans() => _loans.GetAll();
    }
}