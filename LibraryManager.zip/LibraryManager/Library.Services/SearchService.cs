// ============================================================================
// Library.Services - SearchService.cs
// Simple, safe, case-insensitive search across Items and Members.
// ============================================================================
using System.Collections.Generic;
using Library.Domain;

namespace Library.Services
{
    public class SearchService
    {
        private readonly IRepository<Item> _items;
        private readonly IRepository<Member> _members;

        public SearchService(IRepository<Item> items, IRepository<Member> members)
        {
            _items = items; _members = members;
        }

        public List<Item> FindItemsByTitle(string query)
        {
            string q = (query ?? string.Empty).Trim().ToLowerInvariant();
            return _items.Where(i => (i.Title ?? string.Empty).ToLowerInvariant().Contains(q));
        }

        public List<Member> FindMembers(string query)
        {
            string q = (query ?? string.Empty).Trim().ToLowerInvariant();
            return _members.Where(m =>
                (m.FullName ?? string.Empty).ToLowerInvariant().Contains(q) ||
                (m.Email ?? string.Empty).ToLowerInvariant().Contains(q));
        }
    }
}