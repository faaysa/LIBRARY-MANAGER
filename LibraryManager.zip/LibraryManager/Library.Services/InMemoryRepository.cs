// ============================================================================
// Library.Services - InMemoryRepository.cs
// List<T>-backed repository for classroom demos.
// ============================================================================
using System;
using System.Collections.Generic;

namespace Library.Services
{
    public class InMemoryRepository<T> : IRepository<T>
    {
        private readonly List<T> _items = new();

        public IEnumerable<T> GetAll() => _items;
        public void Add(T item) => _items.Add(item);
        public void Remove(Predicate<T> predicate) => _items.RemoveAll(predicate);
        public T? Find(Predicate<T> predicate) => _items.Find(predicate);
        public List<T> Where(Predicate<T> predicate) => _items.FindAll(predicate);
    }
}