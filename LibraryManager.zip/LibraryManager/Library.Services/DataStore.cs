// ============================================================================
// Library.Services - DataStore.cs
// JSON persistence to user's Documents\LibraryManagerData\library.json
// ============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Library.Domain;

namespace Library.Services
{
    public class DataSnapshot
    {
        public List<Item> Items { get; set; } = new();
        public List<Member> Members { get; set; } = new();
        public List<Loan> Loans { get; set; } = new();
    }

    public static class DataStore
    {
        private static readonly string RootDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "LibraryManagerData");
        private static readonly string DataFile = Path.Combine(RootDir, "library.json");

        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true
        };

        public static void Save(IEnumerable<Item> items, IEnumerable<Member> members, IEnumerable<Loan> loans)
        {
            Directory.CreateDirectory(RootDir);
            var snap = new DataSnapshot
            {
                Items = new List<Item>(items),
                Members = new List<Member>(members),
                Loans = new List<Loan>(loans)
            };
            File.WriteAllText(DataFile, JsonSerializer.Serialize(snap, Options));
        }

        public static DataSnapshot? Load()
        {
            try
            {
                if (!File.Exists(DataFile)) return null;
                string json = File.ReadAllText(DataFile);
                return JsonSerializer.Deserialize<DataSnapshot>(json, Options);
            }
            catch { return null; }
        }
    }
}