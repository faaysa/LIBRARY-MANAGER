// ============================================================================
// Library.Services - IRepository.cs
// Generic repository abstraction for in-memory storage.
// ============================================================================
using System;
using System.Collections.Generic;

namespace Library.Services
{
    public interface IRepository<T>
    {
        IEnumerable<T> GetAll();
        void Add(T item);
        void Remove(Predicate<T> predicate);
        T? Find(Predicate<T> predicate);
        List<T> Where(Predicate<T> predicate);
    }
}