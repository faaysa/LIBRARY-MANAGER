// ============================================================================
// Library.App - MainForm.cs (stable v2, over-commented)
// Robust search & delete with guards, and a live status bar.
// ============================================================================
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Library.Domain;
using Library.Services;

namespace Library.App
{
    public class MainForm : Form
    {
        // ---- Repos & Services ----
        private readonly InMemoryRepository<Item> _itemRepo = new();
        private readonly InMemoryRepository<Member> _memberRepo = new();
        private readonly InMemoryRepository<Loan> _loanRepo = new();
        private readonly LoanService _loanService;
        private readonly SearchService _searchService;

        // ---- Master lists bound to grids ----
        private readonly BindingList<Item> _items;
        private readonly BindingList<Member> _members;
        private readonly BindingList<Loan> _loans;

        // ---- UI controls ----
        private readonly TabControl tabs = new();
        private readonly DataGridView gridItems = new();
        private readonly DataGridView gridMembers = new();
        private readonly DataGridView gridLoans = new();
        private readonly TextBox txtSearch = new();
        private readonly Button btnSearch = new();
        private readonly Button btnShowAll = new() { Text = "Show All" };
        private readonly Button btnCheckout = new();
        private readonly Button btnReturn = new();

        // Add/Edit/Delete & status
        private readonly Button btnAddBook = new() { Text = "Add Book" };
        private readonly Button btnAddEBook = new() { Text = "Add EBook" };
        private readonly Button btnEditItem = new() { Text = "Edit Selected Item" };
        private readonly Button btnDeleteItem = new() { Text = "Delete Selected Item" };

        private readonly Button btnAddMember = new() { Text = "Add Member" };
        private readonly Button btnEditMember = new() { Text = "Edit Selected Member" };
        private readonly Button btnDeleteMember = new() { Text = "Delete Selected Member" };

        private readonly Button btnDeleteLoan = new() { Text = "Delete Selected Loan" };

        private readonly StatusStrip status = new();
        private readonly ToolStripStatusLabel lblCounts = new();
        private readonly ToolStripStatusLabel lblSelected = new();

        public MainForm()
        {
            // Load persisted data or seed
            var snap = DataStore.Load();
            if (snap is null)
            {
                foreach (var it in SeedData.Items()) _itemRepo.Add(it);
                foreach (var m in SeedData.Members()) _memberRepo.Add(m);
            }
            else
            {
                foreach (var it in snap.Items) _itemRepo.Add(it);
                foreach (var m in snap.Members) _memberRepo.Add(m);
                foreach (var l in snap.Loans) _loanRepo.Add(l);
            }

            _loanService = new LoanService(_loanRepo);
            _searchService = new SearchService(_itemRepo, _memberRepo);

            _items = new BindingList<Item>(_itemRepo.GetAll().ToList());
            _members = new BindingList<Member>(_memberRepo.GetAll().ToList());
            _loans = new BindingList<Loan>(_loanRepo.GetAll().ToList());

            Text = "Library Manager (Stable v2)";
            Width = 1180; Height = 760;
            StartPosition = FormStartPosition.CenterScreen;

            BuildLayout();
            WireEvents();

            this.FormClosing += (s, e) => DataStore.Save(_items, _members, _loans);
            UpdateStatus();
        }

        private void BuildLayout()
        {
            tabs.Dock = DockStyle.Fill;
            Controls.Add(tabs);

            // ===== Catalog Tab =====
            var tabCatalog = new TabPage("Catalog");
            ConfigureGrid(gridItems);
            gridItems.DataSource = _items;

            var panelSearch = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8) };
            txtSearch.PlaceholderText = "Search title..."; txtSearch.Width = 250;
            btnSearch.Text = "Search";
            panelSearch.Controls.AddRange(new Control[] { txtSearch, btnSearch, btnShowAll });

            var panelItemActions = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8) };
            panelItemActions.Controls.AddRange(new Control[] { btnAddBook, btnAddEBook, btnEditItem, btnDeleteItem });

            tabCatalog.Controls.Add(gridItems);
            tabCatalog.Controls.Add(panelItemActions);
            tabCatalog.Controls.Add(panelSearch);
            tabs.TabPages.Add(tabCatalog);

            // ===== Members Tab =====
            var tabMembers = new TabPage("Members");
            ConfigureGrid(gridMembers);
            gridMembers.DataSource = _members;

            var panelMemberActions = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8) };
            panelMemberActions.Controls.AddRange(new Control[] { btnAddMember, btnEditMember, btnDeleteMember });
            tabMembers.Controls.Add(gridMembers);
            tabMembers.Controls.Add(panelMemberActions);
            tabs.TabPages.Add(tabMembers);

            // ===== Loans Tab =====
            var tabLoans = new TabPage("Loans");
            ConfigureGrid(gridLoans);
            gridLoans.DataSource = _loans;
            var panelLoan = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8) };
            btnCheckout.Text = "Checkout selected"; btnReturn.Text = "Return selected";
            panelLoan.Controls.AddRange(new Control[] { btnCheckout, btnReturn, btnDeleteLoan });
            tabLoans.Controls.Add(gridLoans);
            tabLoans.Controls.Add(panelLoan);
            tabs.TabPages.Add(tabLoans);

            // ===== Status bar =====
            status.Items.Add(lblCounts);
            status.Items.Add(new ToolStripStatusLabel { Spring = true }); // spacer
            status.Items.Add(lblSelected);
            status.Dock = DockStyle.Bottom;
            Controls.Add(status);
        }

        private static void ConfigureGrid(DataGridView grid)
        {
            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AutoGenerateColumns = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false; // Guard: only delete via button logic
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
        }

        private void WireEvents()
        {
            // --- Search ---
            btnSearch.Click += (s, e) =>
            {
                try
                {
                    var results = _searchService.FindItemsByTitle(txtSearch.Text);
                    RefreshItemsList(results);
                }
                catch (Exception ex) { ShowError("Search failed", ex); }
            };

            // Show All restores master list
            btnShowAll.Click += (s, e) =>
            {
                try { RefreshItemsList(_itemRepo.GetAll().ToList()); }
                catch (Exception ex) { ShowError("Reset view failed", ex); }
            };

            // --- Checkout ---
            btnCheckout.Click += (s, e) =>
            {
                try
                {
                    if (gridItems.CurrentRow?.DataBoundItem is not Item item) { MessageBox.Show("Select an Item on Catalog."); tabs.SelectedIndex = 0; return; }
                    if (gridMembers.CurrentRow?.DataBoundItem is not Member mem) { MessageBox.Show("Select a Member on Members."); tabs.SelectedIndex = 1; return; }
                    var loan = _loanService.Checkout(item, mem, 14);
                    _loans.Add(loan);
                    MessageBox.Show($"Checked out: {item.Title} to {mem.FullName}. Due {loan.DueDate:d}");
                    tabs.SelectedIndex = 2;
                    UpdateStatus();
                }
                catch (Exception ex) { ShowError("Checkout failed", ex); }
            };

            // --- Return ---
            btnReturn.Click += (s, e) =>
            {
                try
                {
                    if (gridLoans.CurrentRow?.DataBoundItem is not Loan loan) { MessageBox.Show("Select a Loan on Loans tab."); return; }
                    _loanService.Return(loan);
                    gridLoans.Refresh();
                    decimal fee = _loanService.LateFee(loan, 0.50m);
                    MessageBox.Show($"Returned. Late fee: ${fee:F2}");
                    UpdateStatus();
                }
                catch (Exception ex) { ShowError("Return failed", ex); }
            };

            // --- Add item dialogs ---
            btnAddBook.Click += (s, e) =>
            {
                using var dlg = new BookDialog();
                if (dlg.ShowDialog(this) == DialogResult.OK && dlg.Result is Book b)
                {
                    _itemRepo.Add(b); _items.Add(b); UpdateStatus();
                }
            };
            btnAddEBook.Click += (s, e) =>
            {
                using var dlg = new EBookDialog();
                if (dlg.ShowDialog(this) == DialogResult.OK && dlg.Result is EBook eb)
                {
                    _itemRepo.Add(eb); _items.Add(eb); UpdateStatus();
                }
            };

            // --- Edit item (supports Book/EBook) ---
            btnEditItem.Click += (s, e) =>
            {
                try
                {
                    if (gridItems.CurrentRow?.DataBoundItem is not Item item) { MessageBox.Show("Select an item first."); return; }
                    if (item is Book b) { using var dlg = new BookDialog(b); if (dlg.ShowDialog(this) == DialogResult.OK) gridItems.Refresh(); }
                    else if (item is EBook eb) { using var dlg = new EBookDialog(eb); if (dlg.ShowDialog(this) == DialogResult.OK) gridItems.Refresh(); }
                    UpdateStatus();
                }
                catch (Exception ex) { ShowError("Edit failed", ex); }
            };

            // --- Delete item with active-loan guard ---
            btnDeleteItem.Click += (s, e) =>
            {
                try
                {
                    if (gridItems.CurrentRow?.DataBoundItem is not Item item) { MessageBox.Show("Select an item first."); return; }
                    bool inUse = _loans.Any(l => !l.IsReturned && ReferenceEquals(l.Item, item));
                    if (inUse) { MessageBox.Show("Cannot delete: item has an active loan."); return; }
                    if (MessageBox.Show($"Delete '{item.Title}'?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        _itemRepo.Remove(i => ReferenceEquals(i, item));
                        _items.Remove(item);
                        UpdateStatus();
                    }
                }
                catch (Exception ex) { ShowError("Delete item failed", ex); }
            };

            // --- Member add/edit/delete ---
            btnAddMember.Click += (s, e) =>
            {
                using var dlg = new MemberDialog();
                if (dlg.ShowDialog(this) == DialogResult.OK && dlg.Result is Member m)
                {
                    _memberRepo.Add(m); _members.Add(m); UpdateStatus();
                }
            };

            btnEditMember.Click += (s, e) =>
            {
                try
                {
                    if (gridMembers.CurrentRow?.DataBoundItem is not Member m) { MessageBox.Show("Select a member first."); return; }
                    using var dlg = new MemberDialog(m);
                    if (dlg.ShowDialog(this) == DialogResult.OK) gridMembers.Refresh();
                    UpdateStatus();
                }
                catch (Exception ex) { ShowError("Edit member failed", ex); }
            };

            btnDeleteMember.Click += (s, e) =>
            {
                try
                {
                    if (gridMembers.CurrentRow?.DataBoundItem is not Member m) { MessageBox.Show("Select a member first."); return; }
                    bool inUse = _loans.Any(l => !l.IsReturned && ReferenceEquals(l.Member, m));
                    if (inUse) { MessageBox.Show("Cannot delete: member has an active loan."); return; }
                    if (MessageBox.Show($"Delete member '{m.FullName}'?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        _memberRepo.Remove(x => ReferenceEquals(x, m));
                        _members.Remove(m);
                        UpdateStatus();
                    }
                }
                catch (Exception ex) { ShowError("Delete member failed", ex); }
            };

            // --- Loan delete ---
            btnDeleteLoan.Click += (s, e) =>
            {
                try
                {
                    if (gridLoans.CurrentRow?.DataBoundItem is not Loan loan) { MessageBox.Show("Select a loan first."); return; }
                    if (MessageBox.Show("Delete this loan record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        _loanRepo.Remove(l => ReferenceEquals(l, loan));
                        _loans.Remove(loan);
                        UpdateStatus();
                    }
                }
                catch (Exception ex) { ShowError("Delete loan failed", ex); }
            };

            // --- Selection changed to update status text ---
            gridItems.SelectionChanged += (s, e) => UpdateSelected();
            gridMembers.SelectionChanged += (s, e) => UpdateSelected();
            gridLoans.SelectionChanged += (s, e) => UpdateSelected();
        }

        private void RefreshItemsList(System.Collections.Generic.IEnumerable<Item> items)
        {
            // Rebind pattern avoids re-entrancy / invalid operation exceptions.
            gridItems.EndEdit();
            gridItems.SuspendLayout();
            gridItems.DataSource = null;
            _items.Clear();
            foreach (var it in items) _items.Add(it);
            gridItems.DataSource = _items;
            gridItems.AutoResizeColumns();
            gridItems.ResumeLayout();
            UpdateStatus();
        }

        private void UpdateStatus()
        {
            int books = _items.Count(i => i is Book);
            int ebooks = _items.Count(i => i is EBook);
            int members = _members.Count;
            int activeLoans = _loans.Count(l => !l.IsReturned);
            lblCounts.Text = $"Books: {books}   EBooks: {ebooks}   Members: {members}   Active Loans: {activeLoans}";
            UpdateSelected();
        }

        private void UpdateSelected()
        {
            string msg = "";
            if (tabs.SelectedIndex == 0 && gridItems.CurrentRow?.DataBoundItem is Item i) msg = $"Selected Item: {i.Title}";
            if (tabs.SelectedIndex == 1 && gridMembers.CurrentRow?.DataBoundItem is Member m) msg = $"Selected Member: {m.FullName}";
            if (tabs.SelectedIndex == 2 && gridLoans.CurrentRow?.DataBoundItem is Loan l) msg = $"Selected Loan: {l.Item.Title} → {l.Member.FullName}";
            lblSelected.Text = msg;
        }

        private static void ShowError(string title, Exception ex) =>
            MessageBox.Show($"{title}:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}