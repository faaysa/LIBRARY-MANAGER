//
// ============================================================================
// Library.App - MemberDialog.cs
// Dialog for creating or editing a Member.
// ============================================================================
using System;
using System.Windows.Forms;
using Library.Domain;

namespace Library.App
{
    public class MemberDialog : Form
    {
        private readonly TextBox txtFirst = new() { PlaceholderText = "First Name" };
        private readonly TextBox txtLast  = new() { PlaceholderText = "Last Name" };
        private readonly TextBox txtEmail = new() { PlaceholderText = "Email" };
        private readonly Button btnOk = new() { Text = "OK" };
        private readonly Button btnCancel = new() { Text = "Cancel" };

        public Member? Result { get; private set; }

        public MemberDialog(Member? existing = null)
        {
            Text = existing is null ? "Add Member" : "Edit Member";
            Width = 420; Height = 210; StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;

            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new Padding(10) };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            void addRow(Control c) { panel.Controls.Add(c); panel.SetColumnSpan(c, 2); }
            addRow(txtFirst); addRow(txtLast); addRow(txtEmail);

            var btnPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, Dock = DockStyle.Fill };
            btnPanel.Controls.Add(btnCancel); btnPanel.Controls.Add(btnOk);
            panel.Controls.Add(btnPanel); panel.SetColumnSpan(btnPanel, 2);
            Controls.Add(panel);

            if (existing is not null)
            {
                txtFirst.Text = existing.FirstName;
                txtLast.Text  = existing.LastName;
                txtEmail.Text = existing.Email;
            }

            btnCancel.Click += (s, e) => DialogResult = DialogResult.Cancel;
            btnOk.Click += (s, e) =>
            {
                try
                {
                    var m = existing ?? new Member();
                    m.FirstName = txtFirst.Text;
                    m.LastName  = txtLast.Text;
                    m.Email     = txtEmail.Text;
                    Result = m;
                    DialogResult = DialogResult.OK;
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Validation Error"); }
            };
        }
    }
}