//
// ============================================================================
// Library.App - BookDialog.cs
// Dialog for creating or editing a Book. Over-commented for clarity.
// ============================================================================
using System;
using System.Globalization;
using System.Windows.Forms;
using Library.Domain;

namespace Library.App
{
    public class BookDialog : Form
    {
        private readonly TextBox txtTitle = new() { PlaceholderText = "Title" };
        private readonly TextBox txtAuthor = new() { PlaceholderText = "Author" };
        private readonly TextBox txtYear = new() { PlaceholderText = "Year" };
        private readonly TextBox txtPages = new() { PlaceholderText = "Page Count" };
        private readonly TextBox txtIsbn = new() { PlaceholderText = "ISBN" };
        private readonly Button btnOk = new() { Text = "OK" };
        private readonly Button btnCancel = new() { Text = "Cancel" };

        public Book? Result { get; private set; }

        public BookDialog(Book? existing = null)
        {
            Text = existing is null ? "Add Book" : "Edit Book";
            Width = 420; Height = 260; StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;

            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 6, Padding = new Padding(10) };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            void addRow(Control c) { panel.Controls.Add(c); panel.SetColumnSpan(c, 2); }
            addRow(txtTitle); addRow(txtAuthor); addRow(txtYear); addRow(txtPages); addRow(txtIsbn);

            var btnPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, Dock = DockStyle.Fill };
            btnPanel.Controls.Add(btnCancel); btnPanel.Controls.Add(btnOk);
            panel.Controls.Add(btnPanel); panel.SetColumnSpan(btnPanel, 2);
            Controls.Add(panel);

            if (existing is not null)
            {
                txtTitle.Text = existing.Title;
                txtAuthor.Text = existing.Author;
                txtYear.Text = existing.Year.ToString(CultureInfo.InvariantCulture);
                txtPages.Text = existing.PageCount.ToString(CultureInfo.InvariantCulture);
                txtIsbn.Text = existing.Isbn;
            }

            btnCancel.Click += (s, e) => DialogResult = DialogResult.Cancel;
            btnOk.Click += (s, e) =>
            {
                try
                {
                    var b = existing ?? new Book();
                    b.Title = txtTitle.Text;
                    b.Author = txtAuthor.Text;
                    b.Year = int.Parse(txtYear.Text);
                    b.PageCount = int.Parse(txtPages.Text);
                    b.Isbn = txtIsbn.Text;
                    Result = b;
                    DialogResult = DialogResult.OK;
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Validation Error"); }
            };
        }
    }
}